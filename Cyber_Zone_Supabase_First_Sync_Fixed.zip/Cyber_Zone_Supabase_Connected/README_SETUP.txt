CYBER ZONE - SUPABASE AUTH + SHARED STATE PATCH (UPDATED)

Project URL is configured in index.html. The publishable key is browser-safe; never put a service_role/secret key in website code.

1. In Supabase SQL Editor, open the included SUPABASE_CYBER_ZONE_MEMBERSHIP.sql and run the FULL script. If you see a destructive-operation warning, read the query; this script creates/updates policies and membership and does not drop tables or customer data.
2. This version uses the latest Management UID you supplied: 6e40f787-13a7-46a3-92b4-73bf221f8189 . Confirm it matches Authentication > Users before running.
3. Upload the included index.html to the root of the GitHub Pages repository, replacing the old index.html, and commit changes.
4. Open https://cyberzone.sbs in a private/incognito tab and sign in with the same email/password that exists in Supabase Authentication > Users. Choose Management.
5. Test with dummy data only. Add one item, refresh, and verify it persists.

Important: This starter syncs the app's existing app-state JSON into cz_app_state. It does NOT automatically sync public registration submissions or the customers/daily_work/payments/expenses tables. Do not expose those tables to browser clients without separately designed RLS policies.
