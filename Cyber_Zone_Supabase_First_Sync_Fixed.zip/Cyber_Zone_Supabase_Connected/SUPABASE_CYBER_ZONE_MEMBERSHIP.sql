-- Cyber Zone shared online state: safe starter migration. Run in Supabase SQL Editor.
-- Existing cz_app_state table is retained; this adds organization membership and RLS.
create table if not exists public.cz_org_members (
  user_id uuid primary key references auth.users(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('management','staff')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.cz_app_state enable row level security;
alter table public.cz_org_members enable row level security;

-- Allow Supabase API roles to reach these tables; RLS policies below still restrict rows.
grant select on public.cz_org_members to authenticated;
grant select, insert, update, delete on public.cz_app_state to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- Members can read only their own membership row. Management membership is provisioned below.
drop policy if exists cz_members_read_self on public.cz_org_members;
create policy cz_members_read_self on public.cz_org_members
for select to authenticated using (user_id = auth.uid());

-- App state is shared by accounts in the same organization. Rows use the Management owner's UID.
drop policy if exists cz_state_select_org on public.cz_app_state;
create policy cz_state_select_org on public.cz_app_state
for select to authenticated using (exists (select 1 from public.cz_org_members m where m.user_id=auth.uid() and m.active=true and m.owner_id=cz_app_state.owner_id));
drop policy if exists cz_state_insert_org on public.cz_app_state;
create policy cz_state_insert_org on public.cz_app_state
for insert to authenticated with check (exists (select 1 from public.cz_org_members m where m.user_id=auth.uid() and m.active=true and m.owner_id=cz_app_state.owner_id));
drop policy if exists cz_state_update_org on public.cz_app_state;
create policy cz_state_update_org on public.cz_app_state
for update to authenticated using (exists (select 1 from public.cz_org_members m where m.user_id=auth.uid() and m.active=true and m.owner_id=cz_app_state.owner_id)) with check (exists (select 1 from public.cz_org_members m where m.user_id=auth.uid() and m.active=true and m.owner_id=cz_app_state.owner_id));
drop policy if exists cz_state_delete_management on public.cz_app_state;
create policy cz_state_delete_management on public.cz_app_state
for delete to authenticated using (exists (select 1 from public.cz_org_members m where m.user_id=auth.uid() and m.active=true and m.role='management' and m.owner_id=cz_app_state.owner_id));

-- Register the Management user created in Authentication > Users. UID confirmed from your screenshot.
insert into public.cz_org_members (user_id, owner_id, role, active)
values ('6e40f787-13a7-46a3-92b4-73bf221f8189','6e40f787-13a7-46a3-92b4-73bf221f8189','management',true)
on conflict (user_id) do update set owner_id=excluded.owner_id, role='management', active=true;

-- To add a Staff account: first create that user in Authentication > Users, then insert a membership row
-- with user_id = that user's UID and owner_id = Management UID, role='staff'.
-- NOTE: this protects the cz_app_state table only. Existing customers/daily_work/payments/expenses tables
-- need their own carefully designed policies before exposing them to browser clients.
